# Ag-Fintech Platform Middleware Integrations

Comprehensive Go and Python middleware implementations for the ag-fintech platform with idempotency patterns.

## Overview

This package contains idempotent middleware clients for:

| Middleware | Go | Python | Purpose |
|------------|-----|--------|---------|
| **Kafka** | ✓ | ✓ | Event streaming with exactly-once semantics |
| **Redis** | ✓ | ✓ | Caching, rate limiting, session management |
| **TigerBeetle** | ✓ | ✓ | Double-entry accounting ledger |
| **Temporal** | ✓ | ✓ | Workflow orchestration |
| **Keycloak** | ✓ | ✓ | JWT authentication |
| **Permify** | ✓ | ✓ | Fine-grained authorization (Zanzibar-style) |
| **Dapr** | ✓ | ✓ | Service mesh operations |
| **APISIX** | ✓ | ✓ | API gateway management |
| **Fluvio** | ✓ | ✓ | Alternative event streaming |

## Idempotency Patterns

### 1. Deterministic ID Generation
All IDs are generated from business identifiers using SHA-256 hashing:

```go
// Go
func GenerateKey(prefix string, identifiers ...interface{}) string
func GenerateTransferID(farmerId int, entityType string, entityId int, sequence int) uint64
func GenerateAccountID(farmerID int, accountType uint64) uint64
```

```python
# Python
def generate_key(prefix: str, *identifiers) -> str
def generate_transfer_id(farmer_id: int, entity_type: str, entity_id: int, sequence: int) -> int
def generate_account_id(farmer_id: int, account_type: int) -> int
```

### 2. Idempotency Service
Redis-backed idempotency tracking for operations:

```go
// Go
service := NewIdempotencyService(redisClient, 24*time.Hour)
isNew, existingResult, err := service.TryAcquire(ctx, key)
service.Complete(ctx, key, result)
service.Fail(ctx, key, errorMsg)
```

```python
# Python
service = IdempotencyService(redis_client, timedelta(hours=24))
is_new, existing_result = service.try_acquire(key)
service.complete(key, result)
service.fail(key, error_msg)
```

### 3. Event Deduplication
Exactly-once semantics for Kafka/Fluvio consumers:

```go
// Go
tracker := NewProcessedEventsTracker(redisClient, 7*24*time.Hour)
processed, _ := tracker.IsProcessed(ctx, eventID)
tracker.MarkProcessed(ctx, eventID)
```

```python
# Python
tracker = ProcessedEventsTracker(redis_client, timedelta(days=7))
if tracker.is_processed(event_id):
    continue
tracker.mark_processed(event_id)
```

### 4. Distributed Locks
Lua script-based atomic operations for non-atomic flows:

```go
// Go
lock := NewDistributedLock(redisClient, "resource-name", 30*time.Second)
acquired, _ := lock.Acquire(ctx)
defer lock.Release(ctx)
```

```python
# Python
with DistributedLock(redis_client, "resource-name", timedelta(seconds=30)):
    # critical section
```

## Reference Microservices

### Go Loan Orchestrator (`go-loan-orchestrator/`)
Demonstrates idempotent loan processing:
- `POST /loans/apply` - Apply for a loan (idempotent)
- `POST /loans/approve` - Approve a loan (idempotent)
- `POST /loans/disburse` - Disburse a loan (idempotent)
- `GET /health` - Health check

### Python Loan Worker (`python-loan-worker/`)
Demonstrates idempotent loan processing:
- `POST /loans/apply` - Apply for a loan (idempotent)
- `POST /loans/approve` - Approve a loan (idempotent)
- `POST /loans/disburse` - Disburse a loan (idempotent)
- `GET /loans/<id>` - Get loan application
- `GET /health` - Health check

## Configuration

Environment variables for all middleware:

```bash
# Redis
REDIS_URL=redis://localhost:6379

# Kafka
KAFKA_BROKERS=localhost:9093

# TigerBeetle
TIGERBEETLE_CLUSTER_ID=0
TIGERBEETLE_ADDRESS=127.0.0.1:3000

# Temporal
TEMPORAL_ADDRESS=localhost:7233
TEMPORAL_NAMESPACE=default

# Keycloak
KEYCLOAK_URL=http://localhost:8080
KEYCLOAK_REALM=farmer-realm
KEYCLOAK_CLIENT_ID=farmer-api

# Permify
PERMIFY_URL=http://localhost:3476
PERMIFY_TENANT_ID=default

# Dapr
DAPR_HOST=127.0.0.1
DAPR_HTTP_PORT=3500

# APISIX
APISIX_ADMIN_URL=http://localhost:9180
APISIX_API_KEY=your-api-key

# Fluvio
FLUVIO_ENDPOINT=http://localhost:9003
```

## Usage Examples

### Go

```go
import mw "farmer-platform/services/go/shared/middleware"

// Initialize services
cache, _ := mw.NewCacheService(mw.RedisConfig{URL: "redis://localhost:6379"})
idempotency := mw.NewIdempotencyService(cache.GetClient(), 24*time.Hour)
kafka := mw.NewKafkaClient(mw.KafkaConfig{Brokers: []string{"localhost:9093"}})
tigerbeetle := mw.NewTigerBeetleClient(mw.TigerBeetleConfig{})

// Idempotent operation
key := mw.GenerateKey("operation", farmerId, amount)
isNew, existing, _ := idempotency.TryAcquire(ctx, key)
if !isNew {
    return existing.Result // Return cached result
}

// Do work...
tigerbeetle.RecordLoanDisbursement(ctx, loanId, farmerId, amountCents)

// Publish event
event := mw.CreateDeterministicEvent("CREATED", "loan", loanId, userId, data, key)
kafka.PublishEvent(ctx, mw.Topics.AUDIT_TRAIL, event)

// Mark complete
idempotency.Complete(ctx, key, result)
```

### Python

```python
from shared.middleware import (
    IdempotencyService, CacheService, KafkaClient, TigerBeetleClient,
    generate_key, create_deterministic_event, Topics
)

# Initialize services
cache = CacheService("redis://localhost:6379")
idempotency = IdempotencyService(cache.get_client(), timedelta(hours=24))
kafka = KafkaClient(brokers=["localhost:9093"])
tigerbeetle = TigerBeetleClient()

# Idempotent operation
key = generate_key("operation", farmer_id, amount)
is_new, existing = idempotency.try_acquire(key)
if not is_new:
    return existing.result  # Return cached result

# Do work...
tigerbeetle.record_loan_disbursement(loan_id, farmer_id, amount_cents)

# Publish event
event = create_deterministic_event("CREATED", "loan", loan_id, user_id, data, key)
kafka.publish_event(Topics.AUDIT_TRAIL, event)

# Mark complete
idempotency.complete(key, result)
```

## Interoperability

All implementations use the same:
- Event schema (KafkaEvent with eventId, eventType, entityType, entityId, userId, timestamp, data)
- Topic names (farmer.events, farm.events, audit.trail, etc.)
- Account ID generation formula: `farmerId * 10000 + accountType`
- Transfer ID generation: SHA-256 hash of business identifiers
- Idempotency key format: SHA-256 hash prefix

This ensures TypeScript, Go, and Python services can interoperate seamlessly.

## Production Notes

1. **TigerBeetle**: The implementations include mock clients. Replace with actual TigerBeetle SDK in production.
2. **Temporal**: The implementations include stub clients. Replace with actual Temporal SDK in production.
3. **Keycloak**: JWT verification is simplified. Use proper RSA key construction from JWKS in production.
4. **Error Handling**: All middleware clients use graceful degradation - they log errors but don't throw to avoid cascading failures.
